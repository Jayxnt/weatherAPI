import React, { useState } from 'react';
import SearchBar from './components/SerchBar';
import WeatherInfo from './components/WeatherInfo';
import WeatherDetails from './components/WeatherDetails';
import './App.css';

function App() {
  const [data, setData] = useState({});
  const [location, setLocation] = useState('');
  const [weatherCondition, setWeatherCondition] = useState('');

  const fetchWeather = async (event) => {
    if (event.key === 'Enter') {
      const url = `https://api.openweathermap.org/data/2.5/weather?q=${location}&units=imperial&appid=895284fb2d2c50a520ea537456963d9c`;
      try {
        const response = await fetch(url);
        const result = await response.json();
        setData(result);

        // Extract weather condition
        const condition = result.weather ? result.weather[0].main.toLowerCase() : '';
        setWeatherCondition(condition);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
      setLocation('');
    }
  };

  // Determine class based on weather condition
  const weatherClass = weatherCondition
    ? `app ${weatherCondition}`
    : 'app default';

  return (
    <div className={weatherClass}>
      <SearchBar location={location} setLocation={setLocation} fetchWeather={fetchWeather} />
      <div className="container">
        <WeatherInfo data={data} />
        <WeatherDetails data={data} />
      </div>
    </div>
  );
}

export default App;
