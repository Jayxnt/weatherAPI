import React from 'react';

function SearchBar({ location, setLocation, fetchWeather }) {
  return (
    <div className="search">
      <input
        value={location}
        onChange={(event) => setLocation(event.target.value)}
        onKeyPress={fetchWeather}
        placeholder="Enter Location"
        type="text"
        style={{  width: '100%', marginBottom: '20px',height:'100%' , fontSize: 20 }}
      />
    </div>
  );
}

export default SearchBar;
